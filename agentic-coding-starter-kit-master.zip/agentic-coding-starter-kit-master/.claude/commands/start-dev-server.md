Start the dev server on port 3000.
ALWAYS use port 3000. Use npx kill if the port is in use.
