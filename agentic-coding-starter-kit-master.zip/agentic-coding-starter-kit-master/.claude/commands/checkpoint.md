Please commit all changes and provide a suitable comment for the commit.
Run git init if git has not been instantiated for the project as yet.
